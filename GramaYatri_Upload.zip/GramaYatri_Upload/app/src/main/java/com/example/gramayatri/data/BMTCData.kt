package com.example.gramayatri.data

data class BMTCStop(
    val name: String,
    val lat: Double,
    val lng: Double,
    val isHub: Boolean = false
)

data class BMTCRoute(
    val routeNumber: String,
    val stops: List<String>
)

val BMTC_STOPS = listOf(
    // --- CENTRAL BENGALURU ---
    BMTCStop("Kempagowda Bus Station (Majestic)", 12.9779, 77.5726, true),
    BMTCStop("Shivajinagar Bus Station", 12.9845, 77.5966, true),
    BMTCStop("KR Market", 12.9647, 77.5768, true),
    BMTCStop("MG Road Metro Station", 12.9755, 77.6068),
    BMTCStop("Corporation", 12.9698, 77.5896),
    BMTCStop("Mekhri Circle", 13.0076, 77.5857),
    BMTCStop("Vidhana Soudha", 12.9797, 77.5912),
    BMTCStop("Richmond Circle", 12.9667, 77.5937),
    BMTCStop("Indian Express", 12.9850, 77.5975),

    // --- NORTH BENGALURU (Urban & Rural) ---
    BMTCStop("Hebbal Flyover", 13.0358, 77.5970, true),
    BMTCStop("Yelahanka Old Town", 13.1007, 77.5963, true),
    BMTCStop("Yelahanka NES", 13.0977, 77.5955),
    BMTCStop("Jakkur", 13.0784, 77.6046),
    BMTCStop("Sahakar Nagar", 13.0623, 77.5871),
    BMTCStop("RT Nagar Post Office", 13.0232, 77.5936),
    BMTCStop("Nagawara Junction", 13.0247, 77.6186),
    BMTCStop("Thanisandra", 13.0547, 77.6326),
    BMTCStop("Kalkere", 13.0347, 77.6711),
    BMTCStop("Bagalur", 13.1333, 77.6667),
    BMTCStop("Doddaballapur Bus Stand", 13.2923, 77.5432, true),
    BMTCStop("Devanahalli Old Bus Stand", 13.2483, 77.7126, true),
    BMTCStop("KIA Airport Terminal", 13.1986, 77.7066, true),
    BMTCStop("Chikkajala", 13.1724, 77.6358),
    BMTCStop("Hunasamaranahalli", 13.1415, 77.6105),

    // --- EAST BENGALURU (Urban & Rural) ---
    BMTCStop("Indiranagar 100ft Road", 12.9719, 77.6412),
    BMTCStop("Domlur Bridge", 12.9625, 77.6382),
    BMTCStop("Tin Factory", 13.0039, 77.6751, true),
    BMTCStop("KR Puram Railway Station", 13.0000, 77.6880, true),
    BMTCStop("Marathahalli Bridge", 12.9524, 77.6996, true),
    BMTCStop("Whitefield TTMC", 12.9698, 77.7499, true),
    BMTCStop("ITPL Main Gate", 12.9868, 77.7335),
    BMTCStop("Kadugodi Bus Station", 12.9984, 77.7609, true),
    BMTCStop("Hope Farm Junction", 12.9841, 77.7517),
    BMTCStop("Varthur Kodi", 12.9554, 77.7483),
    BMTCStop("Sarjapur Bus Stand", 12.8624, 77.7836, true),
    BMTCStop("Ramamurthy Nagar", 13.0163, 77.6785),
    BMTCStop("Hoskote Bus Stand", 13.0697, 77.7982, true),
    BMTCStop("Brookefield", 12.9654, 77.7185),
    BMTCStop("HAL Main Gate", 12.9613, 77.6635),

    // --- SOUTH BENGALURU (Urban & Rural) ---
    BMTCStop("Jayanagar 4th Block", 12.9284, 77.5855, true),
    BMTCStop("Banashankari Bus Station", 12.9155, 77.5736, true),
    BMTCStop("Central Silk Board", 12.9174, 77.6231, true),
    BMTCStop("BTM Layout Water Tank", 12.9135, 77.6111),
    BMTCStop("JP Nagar 6th Phase", 12.9105, 77.5857),
    BMTCStop("Electronic City Phase 1", 12.8449, 77.6632, true),
    BMTCStop("Electronic City Phase 2", 12.8339, 77.6782),
    BMTCStop("Bannerghatta National Park", 12.8012, 77.5777, true),
    BMTCStop("AMC Engineering College", 12.8271, 77.5912),
    BMTCStop("Gottigere", 12.8565, 77.5857),
    BMTCStop("HSR Layout 5th Main", 12.9152, 77.6412),
    BMTCStop("Jigani Bus Stand", 12.7845, 77.6321, true),
    BMTCStop("Anekal Bus Stand", 12.7112, 77.6971, true),
    BMTCStop("Chandapura Circle", 12.7933, 77.7011),
    BMTCStop("Kanakapura Road (Thalaghattapura)", 12.8663, 77.5348),
    BMTCStop("Uttarahalli", 12.9063, 77.5358),

    // --- WEST BENGALURU (Urban & Rural) ---
    BMTCStop("Vijayanagar Bus Station", 12.9654, 77.5348, true),
    BMTCStop("Rajajinagar 1st Block", 12.9912, 77.5524),
    BMTCStop("Yeshwanthpur TTMC", 13.0236, 77.5501, true),
    BMTCStop("Kengeri TTMC", 12.9113, 77.4831, true),
    BMTCStop("Nagarbhavi 2nd Stage", 12.9512, 77.5055),
    BMTCStop("RV College", 12.9226, 77.4984),
    BMTCStop("Magadi Road (Toll Gate)", 12.9744, 77.5455),
    BMTCStop("Nelamangala Bus Stand", 13.0967, 77.3912, true),
    BMTCStop("Bidadi Bus Stand", 12.7972, 77.3871, true),
    BMTCStop("Tavarekere", 12.9234, 77.4012),
    BMTCStop("Peenya 2nd Stage", 13.0298, 77.5185),
    BMTCStop("Malleshwaram 18th Cross", 13.0035, 77.5684)
)

val BMTC_ROUTES = listOf(
    // NORTH-SOUTH CONNECTORS
    BMTCRoute("365", listOf("Kempagowda Bus Station (Majestic)", "Corporation", "Jayanagar 4th Block", "JP Nagar 6th Phase", "Gottigere", "AMC Engineering College", "Bannerghatta National Park")),
    BMTCRoute("KIA-9", listOf("Kempagowda Bus Station (Majestic)", "Hebbal Flyover", "Yelahanka Old Town", "Chikkajala", "KIA Airport Terminal")),
    BMTCRoute("285-M", listOf("Kempagowda Bus Station (Majestic)", "Hebbal Flyover", "Yelahanka Old Town", "Doddaballapur Bus Stand")),
    BMTCRoute("368", listOf("Shivajinagar Bus Station", "Corporation", "Jayanagar 4th Block", "JP Nagar 6th Phase", "Gottigere", "AMC Engineering College", "Bannerghatta National Park")),

    // EAST-WEST CONNECTORS
    BMTCRoute("G-3", listOf("Shivajinagar Bus Station", "Indiranagar 100ft Road", "Domlur Bridge", "Marathahalli Bridge", "Whitefield TTMC", "Kadugodi Bus Station")),
    BMTCRoute("226-N", listOf("KR Market", "Vijayanagar Bus Station", "RV College", "Kengeri TTMC", "Bidadi Bus Stand")),
    BMTCRoute("304", listOf("KR Market", "Tin Factory", "KR Puram Railway Station", "Hoskote Bus Stand")),

    // RING ROAD & PERIPHERAL
    BMTCRoute("500-D", listOf("Hebbal Flyover", "Nagawara Junction", "Tin Factory", "Marathahalli Bridge", "Central Silk Board", "Banashankari Bus Station")),
    BMTCRoute("600-F", listOf("Banashankari Bus Station", "JP Nagar 6th Phase", "Central Silk Board", "Electronic City Phase 1", "Chandapura Circle", "Anekal Bus Stand")),
    BMTCRoute("V-500CA", listOf("Hebbal Flyover", "Tin Factory", "Marathahalli Bridge", "Central Silk Board", "Electronic City Phase 1", "Jigani Bus Stand")),

    // LOCAL & RURAL FEEDERS
    BMTCRoute("290-E", listOf("Kempagowda Bus Station (Majestic)", "Shivajinagar Bus Station", "Mekhri Circle", "Nagawara Junction", "Thanisandra", "Kalkere")),
    BMTCRoute("MF-12", listOf("Horamavu Junction", "Ramamurthy Nagar", "Tin Factory", "KR Puram Railway Station")),
    BMTCRoute("258-C", listOf("Kempagowda Bus Station (Majestic)", "Yeshwanthpur TTMC", "Peenya 2nd Stage", "Nelamangala Bus Stand")),
    
    // CROSS-TOWN
    BMTCRoute("K-1", listOf("Yeshwanthpur TTMC", "Mekhri Circle", "Kempagowda Bus Station (Majestic)", "Central Silk Board")),
    BMTCRoute("V-335E", listOf("Kempagowda Bus Station (Majestic)", "MG Road Metro Station", "Indiranagar 100ft Road", "Marathahalli Bridge", "ITPL Main Gate", "Kadugodi Bus Station")),
    BMTCRoute("502", listOf("Hebbal Flyover", "Mekhri Circle", "Majestic (KSRTC)", "Vijayanagar Bus Station"))
)

fun findBMTCRoute(source: String, destination: String): BMTCRoute? {
    // 1. Look for a direct official BMTC route (handle bidirectional)
    BMTC_ROUTES.forEach { route ->
        val sourceIndex = route.stops.indexOf(source)
        val destIndex = route.stops.indexOf(destination)
        
        if (sourceIndex != -1 && destIndex != -1) {
            return if (sourceIndex < destIndex) {
                // Forward direction
                route.copy(stops = route.stops.subList(sourceIndex, destIndex + 1))
            } else {
                // Reverse direction
                route.copy(stops = route.stops.subList(destIndex, sourceIndex + 1).reversed())
            }
        }
    }

    // 2. If no direct route, construct a logical "Shared Transit Log" route
    val sourceStop = BMTC_STOPS.find { it.name == source }
    val destStop = BMTC_STOPS.find { it.name == destination }
    
    if (sourceStop != null && destStop != null) {
        // Find major hubs that are geographically "in between" (simulated by Lat/Lng box)
        val minLat = minOf(sourceStop.lat, destStop.lat)
        val maxLat = maxOf(sourceStop.lat, destStop.lat)
        val minLng = minOf(sourceStop.lng, destStop.lng)
        val maxLng = maxOf(sourceStop.lng, destStop.lng)

        val inBetweenHubs = BMTC_STOPS.filter { 
            it.isHub && 
            it.name != source && 
            it.name != destination &&
            it.lat >= minLat - 0.05 && it.lat <= maxLat + 0.05 &&
            it.lng >= minLng - 0.05 && it.lng <= maxLng + 0.05
        }.take(3).map { it.name }
        
        val dynamicStops = mutableListOf<String>()
        dynamicStops.add(source)
        dynamicStops.addAll(inBetweenHubs)
        dynamicStops.add(destination)
        
        return BMTCRoute(
            routeNumber = "COMMUNITY-${source.take(1)}${destination.take(1)}",
            stops = dynamicStops.distinct()
        )
    }
    
    return null
}
