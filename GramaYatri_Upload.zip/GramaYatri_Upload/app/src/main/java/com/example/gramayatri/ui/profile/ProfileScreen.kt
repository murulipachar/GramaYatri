package com.example.gramayatri.ui.profile

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.example.gramayatri.data.User
import com.example.gramayatri.ui.auth.AuthViewModel
import com.example.gramayatri.ui.theme.ThemeViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    onNavigateBack: () -> Unit,
    onLogout: () -> Unit,
    authViewModel: AuthViewModel,
    profileViewModel: ProfileViewModel,
    themeViewModel: ThemeViewModel,
) {
    val context = LocalContext.current
    val firebaseAuth = FirebaseAuth.getInstance()
    val uid = firebaseAuth.currentUser?.uid
    val userEmail = firebaseAuth.currentUser?.email ?: ""

    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var isUploading by remember { mutableStateOf(false) }
    var showEmailDialog by remember { mutableStateOf(false) }
    var newEmailText by remember { mutableStateOf(userEmail) }

    // Animated Avatars List (Using reliable GIPHY placeholders)
    val animatedAvatars = listOf(
        "https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNHJndXNqZzRocnk1ZWt4Znd4Znd4Znd4Znd4Znd4Znd4JmVwPXYxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/3o7TKMGpxfU251i5Tq/giphy.gif",
        "https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNHJndXNqZzRocnk1ZWt4Znd4Znd4Znd4Znd4Znd4Znd4JmVwPXYxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/l41lTfO3vD7S5u2N2/giphy.gif",
        "https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNHJndXNqZzRocnk1ZWt4Znd4Znd4Znd4Znd4Znd4Znd4JmVwPXYxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/3o7TKVUn7iM8FMEU24/giphy.gif",
        "https://media.giphy.com/media/v1.Y2lkPTc5MGI3NjExNHJndXNqZzRocnk1ZWt4Znd4Znd4Znd4Znd4Znd4Znd4JmVwPXYxX2ludGVybmFsX2dpZl9ieV9pZCZjdD1n/l0HlIDU840iS6z8Uo/giphy.gif"
    )

    // Immediate Sync: Fetch data when the screen opens
    LaunchedEffect(uid) {
        uid?.let { id ->
            FirebaseDatabase.getInstance().getReference("users").child(id).get().addOnSuccessListener { snapshot ->
                val userData = snapshot.getValue(User::class.java)
                userData?.let {
                    name = it.name
                    phone = it.phoneNumber
                    newEmailText = it.email
                }
            }
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            isUploading = true
            profileViewModel.uploadPhoto(it, 
                onSuccess = { url ->
                    authViewModel.updateProfile(name, phone, url) { success ->
                        if (success) {
                            Toast.makeText(context, "Photo Updated!", Toast.LENGTH_SHORT).show()
                        }
                    }
                    isUploading = false
                },
                onFailure = {
                    isUploading = false
                }
            )
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profile & Settings", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 24.dp),
            contentPadding = PaddingValues(bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            // Profile Header Section
            item {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(contentAlignment = Alignment.BottomEnd) {
                        val profileImageUrl = authViewModel.currentUser?.profileImageUrl
                        
                        if (profileImageUrl.isNullOrEmpty()) {
                            Surface(
                                modifier = Modifier
                                    .size(120.dp)
                                    .clip(CircleShape)
                                    .border(4.dp, MaterialTheme.colorScheme.primary, CircleShape),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Icon(
                                    Icons.Default.Person,
                                    contentDescription = null,
                                    modifier = Modifier.padding(24.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        } else {
                            AsyncImage(
                                model = profileImageUrl,
                                contentDescription = "Profile Photo",
                                modifier = Modifier
                                    .size(120.dp)
                                    .clip(CircleShape)
                                    .border(4.dp, MaterialTheme.colorScheme.primary, CircleShape),
                                contentScale = ContentScale.Crop,
                                placeholder = androidx.compose.ui.res.painterResource(android.R.drawable.ic_menu_camera)
                            )
                        }
                        if (isUploading) {
                            CircularProgressIndicator(modifier = Modifier.matchParentSize())
                        }
                        IconButton(
                            onClick = { photoPickerLauncher.launch("image/*") },
                            modifier = Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Photo", modifier = Modifier.size(20.dp), tint = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Or Choose an Animated Avatar:", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp)
                    ) {
                        items(animatedAvatars) { avatarUrl ->
                            AsyncImage(
                                model = avatarUrl,
                                contentDescription = null,
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                                    .border(
                                        width = if (authViewModel.currentUser?.profileImageUrl == avatarUrl) 2.dp else 1.dp,
                                        color = if (authViewModel.currentUser?.profileImageUrl == avatarUrl) MaterialTheme.colorScheme.primary else Color.LightGray,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        authViewModel.updateProfile(name, phone, avatarUrl)
                                        Toast.makeText(context, "Avatar selected!", Toast.LENGTH_SHORT).show()
                                    },
                                contentScale = ContentScale.Crop,
                                placeholder = androidx.compose.ui.res.painterResource(android.R.drawable.ic_menu_gallery)
                            )
                        }
                    }
                }
            }

            // Category: Personal Info
            item {
                ProfileCategory(title = "Personal Info") {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Full Name") },
                        leadingIcon = { Icon(Icons.Default.Person, null) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone Number") },
                        leadingIcon = { Icon(Icons.Default.Phone, null) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                    )
                }
            }

            // Category: Account Security
            item {
                ProfileCategory(title = "Account Security") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = userEmail,
                            onValueChange = {},
                            label = { Text("Email Address") },
                            leadingIcon = { Icon(Icons.Default.Email, null) },
                            readOnly = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(onClick = { showEmailDialog = true }) {
                            Icon(Icons.Default.Edit, contentDescription = "Change Email", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))

                    TextButton(
                        onClick = {
                            if (userEmail.isNotEmpty()) {
                                firebaseAuth.sendPasswordResetEmail(userEmail).addOnSuccessListener {
                                    Toast.makeText(context, "Password reset link sent to $userEmail", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Lock, null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Change Password")
                        }
                    }
                }
            }

            // Category: Preferences
            item {
                ProfileCategory(title = "Preferences") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Dark Mode", style = MaterialTheme.typography.bodyLarge)
                        Switch(
                            checked = themeViewModel.isDarkMode,
                            onCheckedChange = { themeViewModel.toggleDarkMode(it) }
                        )
                    }
                }
            }

            // Save & Logout Buttons
            item {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Button(
                        onClick = { 
                            if (uid == null) {
                                Toast.makeText(context, "User not logged in", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            
                            val db = FirebaseDatabase.getInstance().getReference("users").child(uid)
                            val profileData = mapOf(
                                "name" to name,
                                "phoneNumber" to phone
                            )
                            
                            db.updateChildren(profileData).addOnSuccessListener {
                                Toast.makeText(context, "Success: Profile Saved to Cloud", Toast.LENGTH_SHORT).show()
                                authViewModel.updateProfile(name, phone) {
                                    onNavigateBack()
                                }
                            }.addOnFailureListener { 
                                Toast.makeText(context, "Error: ${it.message}", Toast.LENGTH_LONG).show() 
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("SAVE PROFILE", fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = {
                            authViewModel.logout()
                            onLogout()
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("LOGOUT", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showEmailDialog) {
        AlertDialog(
            onDismissRequest = { showEmailDialog = false },
            title = { Text("Update Email") },
            text = {
                OutlinedTextField(
                    value = newEmailText,
                    onValueChange = { newEmailText = it },
                    label = { Text("New Email") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    authViewModel.updateEmail(newEmailText) { success, error ->
                        if (success) {
                            Toast.makeText(context, "Email updated successfully!", Toast.LENGTH_SHORT).show()
                            showEmailDialog = false
                        } else {
                            Toast.makeText(context, "Error: $error", Toast.LENGTH_LONG).show()
                        }
                    }
                }) { Text("Update") }
            },
            dismissButton = {
                TextButton(onClick = { showEmailDialog = false }) { Text("Cancel") }
            }
        )
    }
}

@Composable
fun ProfileCategory(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 12.dp).align(Alignment.CenterHorizontally)
        )
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
        ) {
            Column(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                content()
            }
        }
    }
}
