package com.example.gramayatri.data

data class BengaluruStop(
    val name: String,
    val isHub: Boolean = false,
    val district: String = "Bengaluru Urban"
)

val BENGALURU_STOPS = listOf(
    BengaluruStop("Kempagowda Bus Station (Majestic)", true),
    BengaluruStop("Banashankari Bus Station", true),
    BengaluruStop("Central Silk Board", true),
    BengaluruStop("Marathahalli Bridge", true),
    BengaluruStop("Hebbal Flyover", true),
    BengaluruStop("Kengeri TTMC", true),
    BengaluruStop("Yeshwanthpur TTMC", true),
    BengaluruStop("Electronic City Phase 1", true),
    BengaluruStop("Tin Factory", true),
    BengaluruStop("Indiranagar 100ft Road"),
    BengaluruStop("Koramangala Water Tank"),
    BengaluruStop("Jayanagar 4th Block"),
    BengaluruStop("Whitefield TTMC", true),
    BengaluruStop("Yelahanka Old Town"),
    BengaluruStop("Bannerghatta National Park"),
    BengaluruStop("Nagawara Junction"),
    BengaluruStop("KR Puram Railway Station", true),
    BengaluruStop("Domlur Bridge"),
    BengaluruStop("Mekhri Circle"),
    BengaluruStop("Rajajinagar 1st Block"),
    BengaluruStop("Vijayanagar Bus Station", true),
    BengaluruStop("Kalkere"),
    BengaluruStop("Horamavu Junction"),
    BengaluruStop("Ramamurthy Nagar"),
    BengaluruStop("Thanisandra")
)

fun getDynamicBengaluruRoute(source: String, destination: String): List<String> {
    val stops = mutableListOf<String>()
    stops.add(source)
    
    // Simple heuristic: Add major hubs that aren't the source or destination
    // In a real implementation, this would be fetched from Google Directions or GTFS
    BENGALURU_STOPS.filter { it.isHub && it.name != source && it.name != destination }
        .shuffled()
        .take(4)
        .map { it.name }
        .forEach { stops.add(it) }
        
    stops.add(destination)
    return stops.distinct()
}

// Estimated travel time between stops in minutes
fun getEstimatedTravelTime(stopIndex: Int): Int {
    // Basic simulation: 8 to 15 minutes between major Bengaluru hubs
    return (stopIndex * 12) 
}
