package com.example.gramayatri.ui.profile

import android.net.Uri
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import java.util.UUID

class ProfileViewModel : ViewModel() {
    private val storage = FirebaseStorage.getInstance().getReference("profile_photos")
    private val auth = FirebaseAuth.getInstance()

    fun uploadPhoto(uri: Uri, onSuccess: (String) -> Unit, onFailure: (String) -> Unit) {
        val uid = auth.currentUser?.uid ?: return
        val fileName = "$uid-${UUID.randomUUID()}"
        val ref = storage.child(fileName)

        ref.putFile(uri)
            .addOnSuccessListener {
                ref.downloadUrl.addOnSuccessListener { url ->
                    onSuccess(url.toString())
                }
            }
            .addOnFailureListener {
                onFailure(it.message ?: "Upload failed")
            }
    }
}
