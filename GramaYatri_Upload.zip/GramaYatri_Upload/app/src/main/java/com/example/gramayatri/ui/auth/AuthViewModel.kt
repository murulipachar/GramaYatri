package com.example.gramayatri.ui.auth

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.gramayatri.data.User
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class AuthViewModel : ViewModel() {
    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance().getReference("users")

    var currentUser by mutableStateOf<User?>(null)
        private set

    var isLoading by mutableStateOf(false)
        private set

    init {
        auth.currentUser?.let { firebaseUser ->
            fetchUserData(firebaseUser.uid)
        }
    }

    private fun fetchUserData(uid: String) {
        isLoading = true
        database.child(uid).get().addOnSuccessListener { snapshot ->
            currentUser = snapshot.getValue(User::class.java)
            isLoading = false
        }.addOnFailureListener {
            isLoading = false
        }
    }

    fun signUp(name: String, email: String, password: String, onResult: (Boolean, String?) -> Unit) {
        isLoading = true
        auth.createUserWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                val uid = result.user?.uid ?: ""
                val user = User(uid, name, email)
                database.child(uid).setValue(user).addOnSuccessListener {
                    currentUser = user
                    isLoading = false
                    onResult(true, null)
                }.addOnFailureListener {
                    isLoading = false
                    onResult(false, it.message)
                }
            }
            .addOnFailureListener {
                isLoading = false
                onResult(false, it.message)
            }
    }

    fun login(email: String, password: String, onResult: (Boolean, String?) -> Unit) {
        isLoading = true
        auth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener { result ->
                fetchUserData(result.user?.uid ?: "")
                onResult(true, null)
            }
            .addOnFailureListener {
                isLoading = false
                onResult(false, it.message)
            }
    }

    fun logout() {
        auth.signOut()
        currentUser = null
    }

    fun updateProfile(name: String, phoneNumber: String = "", imageUrl: String? = null, onResult: (Boolean) -> Unit = {}) {
        val uid = auth.currentUser?.uid ?: return
        isLoading = true
        val updates = mutableMapOf<String, Any>(
            "name" to name,
            "phoneNumber" to phoneNumber
        )
        imageUrl?.let { updates["profileImageUrl"] = it }

        database.child(uid).updateChildren(updates).addOnSuccessListener {
            currentUser = currentUser?.copy(
                name = name,
                phoneNumber = phoneNumber,
                profileImageUrl = imageUrl ?: currentUser?.profileImageUrl ?: ""
            )
            isLoading = false
            onResult(true)
        }.addOnFailureListener {
            isLoading = false
            onResult(false)
        }
    }

    fun updateEmail(newEmail: String, onResult: (Boolean, String?) -> Unit) {
        val firebaseUser = auth.currentUser ?: return
        isLoading = true
        firebaseUser.updateEmail(newEmail).addOnSuccessListener {
            database.child(firebaseUser.uid).child("email").setValue(newEmail).addOnSuccessListener {
                currentUser = currentUser?.copy(email = newEmail)
                isLoading = false
                onResult(true, null)
            }
        }.addOnFailureListener {
            isLoading = false
            onResult(false, it.message)
        }
    }
}
