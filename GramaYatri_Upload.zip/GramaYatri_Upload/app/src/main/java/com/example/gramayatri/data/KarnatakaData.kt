package com.example.gramayatri.data

data class BusStand(
    val name: String,
    val district: String,
    val isMajor: Boolean = false
)

val KARNATAKA_BUS_STANDS = listOf(
    BusStand("Majestic (KSRTC)", "Bengaluru", true),
    BusStand("Hebbal", "Bengaluru", true),
    BusStand("Yelahanka", "Bengaluru", true),
    BusStand("Nelamangala", "Bengaluru Rural", true),
    BusStand("Tumakuru Bus Stand", "Tumakuru", true),
    BusStand("Chitradurga Main Stand", "Chitradurga", true),
    BusStand("Davangere Stand", "Davangere", true),
    BusStand("Hubballi Old Bus Stand", "Dharwad", true),
    BusStand("Dharwad New Stand", "Dharwad", true),
    BusStand("Belagavi Central", "Belagavi", true),
    BusStand("Mysuru Suburban", "Mysuru", true),
    BusStand("Mandya Stand", "Mandya", true),
    BusStand("Shivamogga Stand", "Shivamogga", true),
    BusStand("Hassan City Stand", "Hassan", true),
    BusStand("Mangaluru KSRTC", "Dakshina Kannada", true),
    BusStand("Udupi Service Stand", "Udupi", true),
    BusStand("Vijayapura Stand", "Vijayapura", true),
    BusStand("Kalaburagi Main", "Kalaburagi", true),
    BusStand("Raichur Stand", "Raichur", true),
    BusStand("Ballari Stand", "Ballari", true)
)

fun calculateRouteStops(source: String, destination: String): List<String> {
    // In a real app, this would use a distance matrix or graph algorithm.
    // For this simulation, we return major stands as "Intermediate stops"
    val stops = mutableListOf<String>()
    stops.add(source)
    
    // Logic: If it's a long route, add major hubs in between (simulated)
    KARNATAKA_BUS_STANDS.filter { it.isMajor && it.name != source && it.name != destination }
        .take(5) // Limit for UI cleanliness
        .forEach { stops.add(it.name) }
        
    stops.add(destination)
    return stops.distinct()
}
