package com.example.gramayatri.ui.home

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.gramayatri.data.BusReport
import com.google.firebase.database.*

class HomeViewModel : ViewModel() {
    private val database = FirebaseDatabase.getInstance().reference
    private var lastListener: ValueEventListener? = null
    private var currentPath: DatabaseReference? = null

    var lastReport by mutableStateOf<BusReport?>(null)
        private set

    fun subscribeToRoute(routeNumber: String) {
        // Remove old listener if exists
        lastListener?.let { currentPath?.removeEventListener(it) }
        
        currentPath = database.child("pings").child(routeNumber)
        
        lastListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                lastReport = snapshot.getValue(BusReport::class.java)
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        
        currentPath?.addValueEventListener(lastListener!!)
    }

    fun reportArrival(routeNumber: String, stop: String, userName: String, userPhotoUrl: String, type: String = "Arrived", note: String = "") {
        val report = BusReport(stop, userName, userPhotoUrl, type = type, note = note)
        database.child("pings").child(routeNumber).setValue(report)
    }

    override fun onCleared() {
        super.onCleared()
        lastListener?.let { currentPath?.removeEventListener(it) }
    }
}
