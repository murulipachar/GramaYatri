package com.example.gramayatri.data

data class User(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val profileImageUrl: String = ""
)

data class BusReport(
    val village: String = "",
    val user: String = "",
    val userPhotoUrl: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val type: String = "Arrived", // "Arrived", "Passed", "Canceled"
    val note: String = ""
)
