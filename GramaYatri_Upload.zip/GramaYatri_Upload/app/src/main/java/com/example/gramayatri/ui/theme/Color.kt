package com.example.gramayatri.ui.theme

import androidx.compose.ui.graphics.Color

// Grama Yatri Design Palette
val DeepTeal = Color(0xFF1A5F7A)
val SoftGreen = Color(0xFF159895)
val CleanOffWhite = Color(0xFFF8F9FA)
val AmberAccent = Color(0xFFFFB100)

// Dark Theme Variants
val DeepTealLight = Color(0xFF4B8C9C)
val SoftGreenLight = Color(0xFF4AC4C1)
