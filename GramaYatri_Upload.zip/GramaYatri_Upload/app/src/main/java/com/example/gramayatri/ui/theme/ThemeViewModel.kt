package com.example.gramayatri.ui.theme

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

class ThemeViewModel(application: Application) : AndroidViewModel(application) {
    private val sharedPreferences = application.getSharedPreferences("theme_prefs", Context.MODE_PRIVATE)
    
    var isDarkMode by mutableStateOf(sharedPreferences.getBoolean("is_dark_mode", false))
        private set

    fun toggleDarkMode(isDark: Boolean) {
        isDarkMode = isDark
        sharedPreferences.edit().putBoolean("is_dark_mode", isDark).apply()
    }
}
