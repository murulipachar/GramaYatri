package com.example.gramayatri.ui.home

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import coil3.compose.AsyncImage
import com.example.gramayatri.data.BMTC_STOPS
import com.example.gramayatri.data.findBMTCRoute
import com.example.gramayatri.data.BMTCRoute
import com.example.gramayatri.data.BusReport
import com.example.gramayatri.ui.auth.AuthViewModel
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onNavigateToProfile: () -> Unit,
    authViewModel: AuthViewModel,
    homeViewModel: HomeViewModel
) {
    val context = LocalContext.current
    val user = authViewModel.currentUser
    val lastReport = homeViewModel.lastReport
    
    var source by remember { mutableStateOf("") }
    var destination by remember { mutableStateOf("") }
    var activeRoute by remember { mutableStateOf<BMTCRoute?>(null) }
    var searchExecuted by remember { mutableStateOf(false) }
    
    var showSourceSuggestions by remember { mutableStateOf(false) }
    var showDestSuggestions by remember { mutableStateOf(false) }

    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(12.9716, 77.5946), 12f)
    }
    
    var hasLocationPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { hasLocationPermission = it }

    LaunchedEffect(Unit) {
        if (!hasLocationPermission) permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    LaunchedEffect(hasLocationPermission) {
        if (hasLocationPermission) {
            val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
            try {
                fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                    location?.let {
                        cameraPositionState.position = CameraPosition.fromLatLngZoom(LatLng(it.latitude, it.longitude), 14f)
                    }
                }
            } catch (_: SecurityException) {}
        }
    }

    // Move camera to bus location when report changes
    LaunchedEffect(lastReport) {
        lastReport?.let { report ->
            val busStop = BMTC_STOPS.find { it.name == report.village }
            busStop?.let {
                cameraPositionState.animate(
                    CameraUpdateFactory.newLatLngZoom(LatLng(it.lat, it.lng), 15f)
                )
            }
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("GRAMA YATRI", fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp) },
                actions = {
                    IconButton(onClick = onNavigateToProfile) {
                        Icon(Icons.Default.Person, "Profile", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
            // Low-Data Search Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Box {
                        OutlinedTextField(
                            value = source,
                            onValueChange = { source = it; showSourceSuggestions = it.isNotEmpty() },
                            label = { Text("Village / Source") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )
                        DropdownMenu(expanded = showSourceSuggestions, onDismissRequest = { showSourceSuggestions = false }, properties = androidx.compose.ui.window.PopupProperties(focusable = false)) {
                            BMTC_STOPS.filter { it.name.contains(source, ignoreCase = true) }.take(5).forEach {
                                DropdownMenuItem(text = { Text(it.name) }, onClick = { source = it.name; showSourceSuggestions = false })
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Box {
                        OutlinedTextField(
                            value = destination,
                            onValueChange = { destination = it; showDestSuggestions = it.isNotEmpty() },
                            label = { Text("Destination") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )
                        DropdownMenu(expanded = showDestSuggestions, onDismissRequest = { showDestSuggestions = false }, properties = androidx.compose.ui.window.PopupProperties(focusable = false)) {
                            BMTC_STOPS.filter { it.name.contains(destination, ignoreCase = true) }.take(5).forEach {
                                DropdownMenuItem(text = { Text(it.name) }, onClick = { destination = it.name; showDestSuggestions = false })
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            searchExecuted = true
                            activeRoute = findBMTCRoute(source, destination)
                            activeRoute?.let { homeViewModel.subscribeToRoute(it.routeNumber) }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("VIEW SHARED TRANSIT LOG", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (searchExecuted && activeRoute == null) {
                Text("No direct route found for this pair.", color = MaterialTheme.colorScheme.error, modifier = Modifier.align(Alignment.CenterHorizontally))
            }

            activeRoute?.let { route ->
                Column(modifier = Modifier.weight(1f)) {
                    // Shared Transit Log Header
                    LiveStatusCard(lastReport, route.routeNumber)
                    
                    Text("ROUTE: ${route.routeNumber} TIMELINE", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
                    
                    Box(modifier = Modifier.weight(1f)) {
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            itemsIndexed(route.stops) { index, stop ->
                                val lastSeenIndex = route.stops.indexOf(lastReport?.village)
                                val avgTravelTime = 12 // Simulated average travel time between stops
                                
                                val etaText = when {
                                    lastReport?.type == "Canceled" -> "CANCELED"
                                    lastSeenIndex == -1 -> "Calculating..."
                                    index == lastSeenIndex -> if (lastReport?.type == "Passed") "Just Passed" else "Bus is Here"
                                    index > lastSeenIndex -> {
                                        val mins = (index - lastSeenIndex) * avgTravelTime
                                        "Reach in ~$mins mins"
                                    }
                                    else -> null
                                }

                                GramaTimelineStep(
                                    stop = stop,
                                    isPassed = lastSeenIndex != -1 && index < lastSeenIndex,
                                    isCurrent = lastReport?.village == stop,
                                    isLast = index == route.stops.size - 1,
                                    eta = etaText,
                                    onPing = { type ->
                                        user?.let { 
                                            homeViewModel.reportArrival(route.routeNumber, stop, it.name, it.profileImageUrl, type)
                                            val msg = when(type) {
                                                "Canceled" -> "Reported cancellation at $stop"
                                                "Passed" -> "Reported bus passed $stop"
                                                else -> "Reported bus arrival at $stop"
                                            }
                                            Toast.makeText(context, "$msg! Location updated for everyone.", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                )
                            }
                        }
                    }
                    
                    // Small Map View for context
                    Card(
                        modifier = Modifier.fillMaxWidth().height(150.dp).padding(vertical = 8.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        GoogleMap(
                            modifier = Modifier.fillMaxSize(),
                            cameraPositionState = cameraPositionState,
                            properties = MapProperties(isMyLocationEnabled = hasLocationPermission),
                            uiSettings = MapUiSettings(myLocationButtonEnabled = true, zoomControlsEnabled = false)
                        ) {
                            // Show Bus Marker if location is known
                            lastReport?.let { report ->
                                val busStop = BMTC_STOPS.find { it.name == report.village }
                                busStop?.let {
                                    Marker(
                                        state = MarkerState(position = LatLng(it.lat, it.lng)),
                                        title = "Bus Location",
                                        snippet = "Reported by ${report.user}",
                                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LiveStatusCard(report: BusReport?, routeNo: String) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (report?.type == "Canceled") MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            if (report != null) {
                AsyncImage(model = report.userPhotoUrl, contentDescription = null, modifier = Modifier.size(44.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    val status = when(report.type) {
                        "Canceled" -> "MORNING BUS CANCELED"
                        "Passed" -> "Bus passed ${report.village}"
                        else -> "Bus at ${report.village}"
                    }
                    Text(status, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Source: Reported by ${report.user}", style = MaterialTheme.typography.bodySmall)
                }
                Spacer(modifier = Modifier.weight(1f))
                if (report.type != "Canceled") PulsingLiveBadge()
            } else {
                Icon(Icons.Default.ShareLocation, null, modifier = Modifier.size(32.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("Route $routeNo: LIVE LOG", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Waiting for community pings...", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
fun GramaTimelineStep(stop: String, isPassed: Boolean, isCurrent: Boolean, isLast: Boolean, eta: String?, onPing: (String) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(32.dp).fillMaxHeight()) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(32.dp)) {
                if (isCurrent) {
                    GlowingBusIndicator()
                } else {
                    Surface(modifier = Modifier.size(if (isPassed) 10.dp else 8.dp), shape = CircleShape, color = if (isPassed) MaterialTheme.colorScheme.primary else Color.LightGray) {}
                }
            }
            if (!isLast) {
                Box(modifier = Modifier.width(1.dp).weight(1f).background(if (isPassed) MaterialTheme.colorScheme.primary else Color.LightGray))
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f).padding(bottom = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(stop, fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal, color = if (isCurrent) MaterialTheme.colorScheme.primary else Color.DarkGray, modifier = Modifier.weight(1f))
                if (eta != null) {
                    Text(eta, style = MaterialTheme.typography.labelSmall, color = if (eta == "CANCELED") Color.Red else MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onPing("Arrived") }, modifier = Modifier.height(28.dp), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp), shape = RoundedCornerShape(4.dp)) {
                    Text("ARRIVED", fontSize = 9.sp)
                }
                OutlinedButton(onClick = { onPing("Passed") }, modifier = Modifier.height(28.dp), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp), shape = RoundedCornerShape(4.dp)) {
                    Text("PASSED", fontSize = 9.sp)
                }
                IconButton(onClick = { onPing("Canceled") }, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Warning, "Cancel", tint = Color.Red, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun PulsingLiveBadge() {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "alpha"
    )
    Surface(
        color = Color.Red.copy(alpha = alpha),
        shape = RoundedCornerShape(4.dp)
    ) {
        Text("LIVE", modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 9.sp)
    }
}

@Composable
fun GlowingBusIndicator() {
    val infiniteTransition = rememberInfiniteTransition(label = "glow")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 2f,
        animationSpec = infiniteRepeatable(tween(1500), RepeatMode.Restart), label = "pulse"
    )
    Box(contentAlignment = Alignment.Center) {
        Box(modifier = Modifier.size(10.dp * pulse).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)))
        Surface(modifier = Modifier.size(20.dp), shape = CircleShape, color = MaterialTheme.colorScheme.primary) {
            Icon(Icons.Default.DirectionsBus, null, modifier = Modifier.padding(3.dp), tint = Color.White)
        }
    }
}
