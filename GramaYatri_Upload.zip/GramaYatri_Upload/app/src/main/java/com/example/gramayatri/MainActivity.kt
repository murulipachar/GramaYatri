package com.example.gramayatri

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.gramayatri.ui.auth.AuthViewModel
import com.example.gramayatri.ui.auth.LoginScreen
import com.example.gramayatri.ui.auth.SignupScreen
import com.example.gramayatri.ui.home.HomeScreen
import com.example.gramayatri.ui.home.HomeViewModel
import com.example.gramayatri.ui.profile.ProfileScreen
import com.example.gramayatri.ui.profile.ProfileViewModel
import com.example.gramayatri.ui.theme.GramaYatriTheme
import com.example.gramayatri.ui.theme.ThemeViewModel
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeViewModel: ThemeViewModel = viewModel()
            GramaYatriTheme(darkTheme = themeViewModel.isDarkMode) {
                GramaYatriApp(themeViewModel)
            }
        }
    }
}

@Composable
fun GramaYatriApp(themeViewModel: ThemeViewModel) {
    val navController = rememberNavController()
    val authViewModel: AuthViewModel = viewModel()
    val homeViewModel: HomeViewModel = viewModel()
    val profileViewModel: ProfileViewModel = viewModel()
    
    val firebaseUser = FirebaseAuth.getInstance().currentUser
    val startDestination = if (firebaseUser != null) "home" else "login"

    // Only show the app once we know if we have user data (if logged in)
    if (firebaseUser != null && authViewModel.currentUser == null && authViewModel.isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
    } else {
        NavHost(navController = navController, startDestination = startDestination) {
            composable("login") {
                LoginScreen(
                    onLoginSuccess = { navController.navigate("home") { popUpTo("login") { inclusive = true } } },
                    onNavigateToSignup = { navController.navigate("signup") },
                    viewModel = authViewModel
                )
            }
            composable("signup") {
                SignupScreen(
                    onSignupSuccess = { navController.navigate("home") { popUpTo("login") { inclusive = true } } },
                    onNavigateToLogin = { navController.popBackStack() },
                    viewModel = authViewModel
                )
            }
            composable("home") {
                HomeScreen(
                    onNavigateToProfile = { navController.navigate("profile") },
                    authViewModel = authViewModel,
                    homeViewModel = homeViewModel
                )
            }
            composable("profile") {
                ProfileScreen(
                    onNavigateBack = { navController.popBackStack() },
                    onLogout = { navController.navigate("login") { popUpTo("home") { inclusive = true } } },
                    authViewModel = authViewModel,
                    profileViewModel = profileViewModel,
                    themeViewModel = themeViewModel
                )
            }
        }
    }
}
